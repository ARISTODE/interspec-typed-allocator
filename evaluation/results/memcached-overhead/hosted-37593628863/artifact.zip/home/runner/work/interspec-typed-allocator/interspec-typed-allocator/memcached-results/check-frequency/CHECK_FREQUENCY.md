# Memcached SP3 check frequency

Each row drives 1000 fixed client operations. Counts are taken only from the measured phase; preload and watcher setup are excluded.

| Scenario | Client ops | SP3 checks | Checks/op | Checks/1k ops | offer_input | peek_all | poll | push | request |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| balanced_1c | 1000 | 50 | 0.0500 | 50.0 | 0 | 1 | 1 | 24 | 24 |
| balanced_8c | 1000 | 56 | 0.0560 | 56.0 | 0 | 4 | 4 | 24 | 24 |
| read_heavy_1k | 1000 | 718 | 0.7180 | 718.0 | 0 | 6 | 6 | 353 | 353 |
| write_heavy | 1000 | 0 | 0.0000 | 0.0 | 0 | 0 | 0 | 0 | 0 |
| watch_light | 1000 | 6081 | 6.0810 | 6081.0 | 1500 | 13 | 10 | 1529 | 3029 |
| watch_moderate | 1000 | 6076 | 6.0760 | 6076.0 | 1500 | 10 | 8 | 1529 | 3029 |

The operation columns name the actual protected bridge paths (for example request, push, offer_input, peek, peek_all, or poll). These counts are workload frequencies, not timing measurements.
