# Memcached end-to-end overhead matrix

Positive deltas mean lower throughput. Values are medians; overheads are medians of paired per-repetition ratios.

| Scenario | Practical intent | Native Kops/s | RLBox Kops/s (Δ native) | InterSpec Kops/s (Δ native) | InterSpec Δ vs RLBox | p99 N/R/I (µs) | Loss-free |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| balanced_1c | low-concurrency balanced cache traffic; preserves the paper's 1-client, 1:1, pipeline-10 shape | 143.7 | 138.2 (+3.24%) | 141.2 (+1.34%) | -2.14% | 82.4/85.7/84.4 | yes |
| balanced_8c | higher-concurrency balanced cache traffic; preserves the paper's 8-client, 1:1, pipeline-10 shape | 650.7 | 662.8 (+0.20%) | 641.5 (+1.42%) | +1.22% | 304.6/314.1/328.6 | yes |
| read_heavy_1k | read-mostly object-cache scenario with 1 KiB values | 897.3 | 839.3 (+6.47%) | 809.6 (+10.00%) | +0.02% | 448.7/491.6/507.5 | yes |
| write_heavy | mutation-heavy scenario stressing SET paths and asynchronous LRU activity | 565.7 | 576.1 (-2.89%) | 558.8 (-0.54%) | +3.00% | 304.0/293.4/318.9 | yes |
| watch_light | lossless active-observability scenario with a live watcher | 18.3 | 18.4 (-2.77%) | 18.4 (-0.66%) | +0.11% | 69.0/70.0/70.5 | yes |
| watch_moderate | moderate active-observability load with worker and watcher queues exercised continuously | 75.1 | 72.3 (+3.06%) | 73.4 (+2.80%) | +0.85% | 79.5/81.8/82.5 | yes |

The balanced 1-client and 8-client scenarios preserve the original InterSpec memcached/bipbuffer workload shape of a 1:1 GET/SET ratio with pipeline depth 10 while making value size and working-set size explicit.
Watcher scenarios are accepted for the main table only when every timed run has zero logger and LRU drops. A lossy run is retained as raw evidence but must not be interpreted as an overhead result.
