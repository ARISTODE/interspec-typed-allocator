#!/usr/bin/env bash
set -euo pipefail
root=/workspace/scratch/521dc1dee07c/interspec-typed-allocator
work=/tmp/interspec-nginx-deployment
deps=/tmp/interspec-nginx-backend
jobs=2
pcre="$work/pcre"
generated="$work/generated"
wabt="$deps/build/_deps/wasm2c_compiler-src"
wasi="$deps/build/_deps/wasiclang-src"
includes=(-I"$deps/include" -I"$deps/build/_deps/rlbox-src/code/include"
  -I"$wabt/wasm2c" -I"$wabt/third_party/simde" -I"$generated" -I"$root/include" -I"$pcre")
defines=(-DWASM_RT_USE_MMAP=1 -DWASM_RT_SKIP_SIGNAL_RECOVERY=1 -DWASM_RT_NONCONFORMING_UNCHECKED_STACK_EXHAUSTION=1)
if grep -q 'interspecWasm' "$work/ordinary/glue_lib_wasm2c.h"; then
  echo 'RLBox-only module unexpectedly imports typed allocation' >&2; exit 1
fi
if grep -q 'interspec_nginx_fault' "$work/typed/glue_lib_wasm2c.h"; then
  echo 'Release module unexpectedly contains fault hooks' >&2; exit 1
fi

# Link the unchanged nginx objects with the PCRE ABI bridge instead of libpcre.
python3 - "$work/server/objs/Makefile" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
assert s.count('-lpcre') == 1
s=s.replace('-lpcre', '$(INTERSPEC_BRIDGE) $(INTERSPEC_MODULE) -lstdc++ -pthread -ldl -lrt -lm')
p.write_text(s)
PY
for variant in rlbox-only tracked-no-check interspec diagnostics; do
  module=typed
  flags=(-DINTERSPEC_TRACKING=1 -DINTERSPEC_CHECKS=0)
  case $variant in
    rlbox-only) module=ordinary; flags=(-DINTERSPEC_TRACKING=0 -DINTERSPEC_CHECKS=0);;
    interspec) flags=(-DINTERSPEC_TRACKING=1 -DINTERSPEC_CHECKS=1);;
    diagnostics) module=fault; flags=(-DINTERSPEC_TRACKING=1 -DINTERSPEC_CHECKS=1 -DINTERSPEC_ENABLE_TRACE=1 -DINTERSPEC_FAULT_TESTS=1);;
  esac
  g++ -std=c++17 -O2 "${defines[@]}" "${flags[@]}" "${includes[@]}" -I"$work/$module" \
    -c "$root/integration/nginx_server/bridge.cpp" -o "$work/$variant-bridge.o"
  rm -f "$work/server/objs/nginx"
  make -C "$work/server" -j"$jobs" INTERSPEC_BRIDGE="$work/$variant-bridge.o" \
    INTERSPEC_MODULE="$work/$module/module.a" > "$work/logs/$variant-build.log" 2>&1
  cp "$work/server/objs/nginx" "$work/bin/nginx-$variant"
done
python3 - "$root" "$work" <<'PY'
import hashlib,json,subprocess,sys
from pathlib import Path
root,work=map(Path,sys.argv[1:])
def rev(p): return subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
info={'project_commit':rev(root),'project_dirty':bool(subprocess.check_output(['git','-C',str(root),'status','--porcelain'])),
 'nginx_revision':rev(work/'upstream'),'pcre_revision':rev(work/'pcre'),
 'source_sha256':{str(p.relative_to(root)):sha(p) for p in sorted((root/'integration/nginx_server').glob('*')) if p.is_file()},
 'binary_sha256':{p.name:sha(p) for p in sorted((work/'bin').glob('nginx-*'))},
 'scope':'PCRE8 interpreter; HTTP; nginx event loop; no TLS, PCRE2, JIT, or threaded third-party regex calls',
 'limits':{'subject_bytes':65536,'offset_ints':4096,'typed_arena_bytes_per_regex':1048576}}
for name in ['scripts/build_nginx_deployment.sh','tools/prepare_nginx_deployment.py','tools/generate_wasm_boundary_policy.py',
             'tools/nginx_common.py','tools/test_nginx_deployment.py','tools/benchmark_nginx.py']:
 info['source_sha256'][name]=sha(root/name)
info['generated_sha256']={p.name:sha(p) for p in sorted((work/'generated').glob('*')) if p.is_file()}
(work/'build-manifest.json').write_text(json.dumps(info,indent=2)+'\n')
PY
