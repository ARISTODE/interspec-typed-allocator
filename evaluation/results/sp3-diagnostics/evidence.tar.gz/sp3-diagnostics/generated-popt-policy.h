#pragma once

#include "interspec/runtime.h"
#include <limits>

namespace interspec::rsync_popt_generated {

struct AccessPolicy {
  uint64_t type_hash;
  size_t offset;
  size_t bytes;
};

struct WasmAllocationSitePolicy {
  SiteId site_id;
  TypeId type_id;
  const char* import_name;
  bool helper;
};

constexpr TypeId kTypeIdChar = 1;
constexpr uint64_t kTypeHashChar = UINT64_C(214265502);
constexpr TypeId kTypeIdPoptContextS = 2;
constexpr uint64_t kTypeHashPoptContextS = UINT64_C(1123223977022939130);

constexpr SiteId kWasmSiteIdBase = UINT32_C(0);

inline bool register_types(Runtime& runtime)
{
  bool ok = true;
  ok = runtime.register_type(kTypeIdChar, kTypeHashChar) && ok;
  ok = runtime.register_type(kTypeIdPoptContextS, kTypeHashPoptContextS) && ok;
  return ok;
}

constexpr size_t kWasmPreciseAllocationSiteCount = 2;
constexpr size_t kWasmHelperAllocationSiteCount = 1;
constexpr size_t kWasmAllocationSiteCount = 3;
constexpr WasmAllocationSitePolicy kWasmAllocationSites[] = {
  {1, kTypeIdChar, "interspecWasmAllocInterspecRsyncPoptGeneratedSite1", false},
  {2, kTypeIdPoptContextS, "interspecWasmAllocInterspecRsyncPoptGeneratedSite2", false},
  {3, kTypeIdChar, "interspecWasmAllocInterspecRsyncPoptGeneratedSite3", true},
};

inline bool register_wasm_allocation_policy(Runtime& runtime)
{
  for (const auto& site : kWasmAllocationSites) {
    if (!runtime.register_allocation_site_id(site.site_id, site.type_id))
      return false;
  }
  return true;
}

constexpr AccessPolicy kUsePoptOptArgFirstByte{
  kTypeHashChar, 0, 1};

inline CheckResult check(const Runtime& runtime, uintptr_t base,
                         size_t dynamic_bytes, AccessPolicy policy)
{
  const size_t bytes = policy.bytes ? policy.bytes : dynamic_bytes;
  if (policy.offset > std::numeric_limits<size_t>::max() - bytes)
    return CheckResult::out_of_bounds;
  return runtime.check(base, policy.offset + bytes, policy.type_hash);
}

}  // namespace interspec::rsync_popt_generated
